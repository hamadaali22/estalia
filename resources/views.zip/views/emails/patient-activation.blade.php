Welcome, please click on this link to activate your account : {{ url('doctor/activation', $link)}}
