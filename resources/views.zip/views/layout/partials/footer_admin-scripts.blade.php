	<!-- jQuery -->
				
	<script src=" {{asset('assets_admin/js/jquery-3.2.1.min.js')}}"></script>
		
		
						
        <script src="{{asset('assets_admin/js/popper.min.js')}}"></script>
        
		<script src="{{asset('assets_admin/plugins/bootstrap-rtl/js/bootstrap.min.js')}}"></script>
		
		
		
        <script src="{{asset('assets_admin/plugins/slimscroll/jquery.slimscroll.min.js')}}"></script>
		@if(Route::is(['page']))
		
		<script src="{{asset('assets_admin/plugins/raphael/raphael.min.js')}}"></script>  
		  
		<script src="{{asset('assets_admin/plugins/morris/morris.min.js')}}"></script>  
		
		<script src="{{asset('assets_admin/js/chart.morris.js')}}"></script>
		@endif
		
        <script src="{{asset('assets_admin/js/form-validation.js')}}"></script>
		
		
		<script src="{{asset('assets_admin/js/jquery.maskedinput.min.js')}}"></script>
		
        <script src="{{asset('assets_admin/js/mask.js')}}"></script>
		
			
			<script src="{{asset('assets_admin/js/select2.min.js')}}"></script>
		
			
			
			<script src="{{asset('assets_admin/js/moment.min.js')}}"></script>
			
		<script src="{{asset('assets_admin/js/bootstrap-datetimepicker.min.js')}}"></script>
		
		
		
        <script src="{{asset('assets_admin/js/jquery-ui.min.js')}}"></script>
        
        <script src="{{asset('assets_admin/plugins/fullcalendar/fullcalendar.min.js')}}"></script>
        
        <script src="{{asset('assets_admin/plugins/fullcalendar/jquery.fullcalendar.js')}}"></script>
		
		
		<script src="{{asset('assets_admin/plugins/fullcalendar/jquery.fullcalendar.js')}}"></script>
		
		<script src="{{asset('assets_admin/plugins/datatables/datatables.min.js')}}"></script>	
		
		
		<script  src="{{asset('assets_admin/js/script.js')}}"></script>
		

		 <script src="{{asset('assets/js/app.min.js')}}"></script>
		



				
			<script src="{{asset('asset/js/table.min.js')}}"></script>
		
			
			<script src="{{asset('asset/js/admin.js')}}"></script>
			
			<script src="{{asset('asset/js/pages/tables/jquery-datatable.js')}}"></script>
		