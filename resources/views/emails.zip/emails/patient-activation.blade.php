Wellcome, {{ $name }}
Please active your account : {{ url('patient/activation', $link)}}
