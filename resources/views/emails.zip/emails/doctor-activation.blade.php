Wellcome, {{ $name }}
Please active your account : {{ url('doctor/activation', $link)}}
