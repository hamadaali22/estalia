<?php

namespace App\Providers;
use App\ContactInfo;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {

        
        // View::composer(['*'], function($view){
        //      $cont = ContactInfo::first();
        //     $view->with('contact',$cont);
        //     dd($cont);
        // });
        $cont = ContactInfo::first();
        view()->share('contact', $cont);

    }
}
